import { useContext, useEffect, useState } from "react"
import { getDocs } from "firebase/firestore";
import { doc, deleteDoc } from "firebase/firestore";
import { db,collection,} from "../firebase";
import { StateContext } from "../Context/StateProvider";
import { Navbar } from "./Navbar";
import styles from "../Styles/Favourite.module.css";

export const Favourite = () => {
    const { userData, isAuth } = useContext(StateContext);
    const [itemIsPresent, setItemIsPresent] = useState(true);
    const [data, setData] = useState([]);
    const fetchData = async () => {
        const querySnapshot = await getDocs(collection(db, userData.uid));
        let arr = [];
        querySnapshot.forEach(async (doc) => {
        // doc.data() is never undefined for query doc snapshots
            // console.log(doc.id, " => ", doc.data());
            arr.push(doc.data());
        });
        setData(arr);
    }
    const handleRemove = async (name) => {
        console.log("name: ",name)
        //await deleteDoc(doc(db, userData.uid, "DC"));
        const querySnapshot = await getDocs(collection(db, userData.uid));
        let arr = [];
        let id;
        querySnapshot.forEach(async (doc) => {
        // doc.data() is never undefined for query doc snapshots
            // console.log(doc.id, " => ", doc.data());
            if (doc.data().cryptoName == name) {
                id = doc.id;
            }
        });
        await deleteDoc(doc(db, userData.uid, id));
        setItemIsPresent(false);
    }
    useEffect(() => {
        fetchData(); 
    }, [itemIsPresent])
    if(!isAuth){window.location.href="/"}
    return (
        <div>
            <Navbar />
            <div className={styles.itemContainer}>
                {data.length > 0 && data.map((item) => {
                return <div className={styles.favouriteItem}>
                        <div>
                            {item.cryptoName}
                        </div>
                        <div>
                            &#x20B9; {item.price}
                        </div>
                        <div>
                            <button onClick={()=>handleRemove(item.cryptoName)}>Remove</button>
                        </div>
                    </div>
                })}
            </div>
        </div>
    )
}